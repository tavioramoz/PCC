from django.contrib import admin
from avaliacao.models import Avaliacao

# Register your models here.
admin.site.register(Avaliacao)
