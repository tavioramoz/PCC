from django.contrib import admin
from empresa.models import Empresa

admin.site.register(Empresa)