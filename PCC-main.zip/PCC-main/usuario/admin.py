from django.contrib import admin
from usuario.models import Usuario

# Register your models here.
admin.site.register(Usuario)
