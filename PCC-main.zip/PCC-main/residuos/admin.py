from django.contrib import admin
from .models import Residuos

admin.site.register(Residuos)